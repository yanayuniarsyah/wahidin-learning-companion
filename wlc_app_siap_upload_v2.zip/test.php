<?php
$ch = curl_init('https://wlc.kumonwahidincilacap.com/api/login');
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['username'=>'owner','password'=>'owner123']));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$res = curl_exec($ch);
if ($res === false) { die("Curl error: " . curl_error($ch)); }
$json = json_decode($res);
if (!isset($json->token)) { die("Login failed: " . $res); }
$token = $json->token;
$ch2 = curl_init('https://wlc.kumonwahidincilacap.com/api/siswa?token='.$token);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
echo "DATA: " . curl_exec($ch2);
?>
